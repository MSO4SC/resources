#!/bin/bash

source modules.source 
source environment.source 

#############################
# OPM-UPSCALING
#############################

MODULENAME=opm-upscaling

SRC_DIR=$ROOT/$MODULENAME
BUILD_DIR=$SRC_DIR/build
INSTALL_DIR="$ROOT_INSTALL_DIR/$MODULENAME"

if [ "$CLEANALL" == "true" ]; then rm -rf $SRC_DIR; fi
if [ "$CLEAN" == "true" ]; then rm -rf $BUILD_DIR; fi


if [ "$DOWNLOAD" == "true" ]; then 
    git clone -b release/$OPM_RELEASE/final https://github.com/OPM/$MODULENAME.git $SRC_DIR
    sed -i 's/log2(/log2((double)/g' $(SRC_DIR)/opm/elasticity/elasticity_upscale_impl.hpp
fi

mkdir -p $BUILD_DIR
cd $BUILD_DIR

if [ "$CONFIGURE" == "true" ]; then 
    $CMAKE -DCMAKE_INSTALL_PREFIX=$INSTALL_DIR \
           -DCMAKE_C_COMPILER=gcc \
           -DCMAKE_CXX_COMPILER=g++ \
           -DCMAKE_C_FLAGS="-mtune=haswell -mfma -malign-data=cacheline -finline-functions -lc " \
           -DCMAKE_CXX_FLAGS="-march=haswell -mfma -malign-data=cacheline -finline-functions -lc " \
           -DCMAKE_EXE_LINKER_FLAGS="-lc" \
           -DCMAKE_MODULE_LINKER_FLAGS="-lc" \
           -DCMAKE_SHARED_LINKER_FLAGS="-lc" \
           -DCMAKE_STATIC_LINKER_FLAGS="-lc" \
           -DBLAS_blas_LIBRARY=$BLAS_LAPACK_MKL_LIBS \
           -DUSE_OPENMP=ON \
           -DUSE_MPI=ON \
           $SRC_DIR
fi

if [ "$BUILD" == "true" ]; then $MAKE VERBOSE=1 ; fi
if [ "$TEST" == "true" ]; then $CTEST; fi
if [ "$INSTALL" == "true" ]; then $MAKE install; fi

