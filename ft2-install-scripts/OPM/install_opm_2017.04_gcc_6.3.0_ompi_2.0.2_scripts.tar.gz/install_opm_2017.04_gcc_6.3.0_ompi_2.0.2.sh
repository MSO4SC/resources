#!/bin/bash

#############################
# OPM COMPILATION SCRIPTS
#############################

OPM_SCRIPTS="opm-data       \
             opm-common     \
             opm-parser     \
             opm-material   \
             opm-grid       \
             opm-output     \
             opm-core       \
             ewoms          \
             opm-simulators \
             opm-upscaling  \
             ResInsight"


for script in $OPM_SCRIPTS;
do
    echo ""
    echo "######################################"
    echo "EXECUTING: $script".sh
    echo "######################################"
    echo ""

    ./$script.sh $@
done
