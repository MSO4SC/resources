#!/bin/bash

source modules.source
source environment.source

#############################
# OPM DATA
#############################

cd $ROOT
MODULENAME=opm-data
SRC_DIR=$ROOT/$MODULENAME

if [ "$CLEANALL" == "true" ]; then rm -rf $SRC_DIR; fi

if [ "$DOWNLOAD" == "true" ]; then
    git clone -b release/$OPM_RELEASE/final https://github.com/OPM/$MODULENAME.git $SRC_DIR
fi
