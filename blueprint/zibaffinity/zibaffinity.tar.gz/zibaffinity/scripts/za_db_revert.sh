#!/bin/bash -l

if [ -f $2/$3 ]; then
	rm $2/$3
fi

#if [ -f $1/$2 ]; then
#	rm $1/$2
#fi
